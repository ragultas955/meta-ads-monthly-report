# Report Spec: Sections and Design

## Contents
- Metrics used in the report
- Section 1: Cover
- Section 2: Overall Performance Insights
- Section 3: Campaign List
- Section 4: Age Analysis
- Section 5: Gender Analysis
- Section 6: Device and Placement Analysis
- Section 7: Overall Performance Summary
- Design standards
- Final quality checklist

## Metrics used in the report

| Metric | Definition | Type |
|---|---|---|
| Reach | Unique accounts reached | Reported |
| Impressions | Total times ads were displayed | Reported |
| Results | Count of the campaign's result type in Ads Manager | Reported |
| CPR | Cost ÷ Results, for one result type | Reported (or calculated, label it) |
| CPC | Cost per click. State the basis: link clicks or all clicks | Reported (or calculated, label it) |
| CPM | Cost per 1,000 impressions = Cost ÷ Impressions × 1,000 | Reported (or calculated, label it) |
| Frequency | Impressions ÷ Reach | Calculated |
| Cost | Total spend in the source currency | Reported |

Add a small footnote listing which values are calculated (for example "Frequency = Impressions ÷ Reach; CPM = Cost ÷ Impressions × 1,000"). Name the result type next to every CPR. If result types differ across campaigns, show CPR per result type and never compare across them.

## Section 1: Cover

- Title: **Monthly Meta Ads Performance Report**
- Advertiser / brand name from the runtime input
- Reporting period (month and year, or date range)
- Minimal, premium, corporate: strong title hierarchy, generous whitespace, name and period clearly visible. A thin rule or a restrained accent block is enough. No generic gradients, oversized shapes, or illustrations.
- Never show the ad account ID.

## Section 2: Overall Performance Insights

Account-level results for the whole period.

- **KPI strip** with five metrics: Reach, Impressions, CPR (with result type), Total cost, Frequency.
- **Reach / impressions / frequency infographic**: impressions as the larger volume, reach as the unique-account base, frequency as the ratio linking them. Explanatory, not decorative.
- **Month-over-month deltas** only if previous-month data was provided. Otherwise omit; never invent comparisons.
- **3-4 insight statements** on delivery scale, spend distribution, cost efficiency, or frequency, each tied to a number.

Campaign-level detail belongs in Section 3, so do not repeat it here.

## Section 3: Campaign List

One table listing every campaign that delivered in the period. It follows directly after the overall insights.

**Columns, in this order:**

| # | Column | Notes |
|---|---|---|
| 1 | Campaign name | Wrap to two lines if needed; never truncate silently |
| 2 | Reach | Per-campaign unique reach |
| 3 | Impressions | |
| 4 | CPR | Cost per result, in the source currency |
| 5 | Results | Show the result type as a small secondary line under the number (for example "Messages", "Leads", "Link clicks") |
| 6 | CPC | State the click basis in the header or footnote |
| 7 | CPM | |
| 8 | Frequency | |
| 9 | Cost | Amount spent, in the source currency |

**Rows and totals**

- Sort by Cost, highest first.
- Include campaigns with delivery in the period. Exclude campaigns with zero impressions and zero cost, and say how many were excluded in the footnote.
- Add a **Total** row:
  - Reach: the account-level unique reach, not the sum of rows. Footnote: "Total reach is account-level; campaign reach overlaps."
  - Impressions, Cost: sums.
  - Results and CPR: total and blended CPR only if every campaign shares one result type; otherwise `N/A` and a footnote that result types differ.
  - CPM: Total cost ÷ Total impressions × 1,000 (calculated).
  - CPC: Total cost ÷ Total clicks only if click counts are in the data; otherwise `N/A`.
  - Frequency: Total impressions ÷ account-level reach (calculated).
- Missing value in a cell → `N/A`, never blank, never zero unless the source says zero.

**Fitting many campaigns**

- Up to 10 campaigns per slide, table text no smaller than 10 pt. Beyond 10, continue on "Campaign List (continued)" slides, repeating the header row, and put the Total row only on the last one.
- HTML report: one table, horizontally scrollable inside its own container on small screens, sticky header row.
- Never drop campaigns to make it fit and never merge them into an "Other" row.

**Supporting content**

- 2-3 insight statements: spend concentration (for example the share of cost held by the top campaigns), CPR spread within one result type, and the frequency range across campaigns. Name the metric each time.
- Optional thin in-cell data bars for Cost. Keep them subtle and zero-based.

## Section 4: Age Analysis

All age groups present in the source (for example 18-24, 25-34, 35-44, 45-54, 55-64, 65+, and any unknown bucket).

- Horizontal bar chart: reach or impressions by age group.
- Second compact visual: cost or CPR by age group.
- Data table with exact Reach, Impressions, CPR, Cost, Frequency per age group.
- Highlight the strongest or weakest segment only when the data clearly supports it, and say on which metric. The highest-reach group is not automatically the most cost-efficient.
- 2-4 insights: which groups contributed the most reach, impressions, and spend; how CPR and frequency differed.

## Section 5: Gender Analysis

All categories in the source, including unknown or unspecified. Never drop a category silently.

- Comparison chart for reach or impressions.
- Separate visual for cost share and CPR.
- Compact table: Reach, Impressions, CPR, Cost, Frequency per category.
- Neutral, professional styling: no gendered colour coding or imagery.
- 2-4 insights on audience scale, spend, CPR, frequency. Do not infer purchase intent, product preference, or demographic behaviour from delivery metrics.

## Section 6: Device and Placement Analysis

Two clearly separated halves, visually distinct (different header band or column), because they are different breakdown dimensions and must never be merged into one comparison.

**A. Device Analysis**: Mobile, Desktop, and any other device categories present.
**B. Placement Analysis**: only placements actually present (for example Facebook Feed, Instagram Feed, Instagram Stories, Instagram Reels, Facebook Reels, Audience Network, others). Do not list absent placements.

For each half:
- Horizontal bar chart for reach or impressions.
- A separate chart for cost distribution or CPR.
- Compact table with exact Reach, Impressions, CPR, Cost, Frequency.

3-4 insights across the section on delivery concentration, spend distribution, CPR differences, and frequency. Do not call a placement "best-performing" on reach or impressions alone, and never add overlapping placement or audience reach together to claim a unique total.

If the slide gets crowded, shrink table font to no less than 10 pt and trim chart labels before cutting required data. Do not drop a required table.

## Section 7: Overall Performance Summary

Five compact infographic blocks: **Overall**, **Campaigns**, **Age**, **Gender**, **Device and Placement**.

- Each block: 1-2 prominent metrics plus one or two concise supporting lines (for example the leading age groups by reach, the CPR spread within a result type, the main placements by spend, the share of cost in the top campaign).
- Do not repeat every data point from earlier sections.
- End with a one- or two-sentence factual overall conclusion describing what the data showed.
- Observed performance only: no recommendations, next steps, budget changes, or calls to action.

## Design standards

- PowerPoint: 16:9 widescreen, native editable charts and tables.
- Palette: use the brand's colours only if the user supplies guidelines or a logo. Otherwise use a neutral light background, dark charcoal text, and one or two restrained accent colours, held constant across all sections. Accent colour is for emphasis, not decoration.
- One typeface family, a clear size hierarchy (title, metric value, label, body), and consistent number formatting (thousands separators, currency symbol or code, fixed decimals for CPR, CPC, CPM, and frequency).
- Consistent grid and margins. Headings, charts, tables, and insight text each live in defined zones. Use thin dividers and whitespace rather than putting everything in cards.
- Direct data labels on charts instead of heavy legends. Clear chart titles with units. Bar charts start at zero.
- Vary layouts between sections (age, gender, and placement can share a chart-plus-table logic but should not be pixel clones), while keeping the grid consistent.
- Avoid: generic dashboard look, many rounded cards, heavy gradients, glassmorphism, neon, shadows, decorative icons or stock imagery, oversized headings that squeeze content, dense paragraphs, tiny footnotes.
- Insight text: short bullets, body no smaller than 11-12 pt; table text no smaller than 10 pt.

## Final quality checklist

Confirm each item before delivering:

- [ ] Every number matches the source; derived values were recomputed.
- [ ] CPR uses the correct result count, the result type is named, and no CPR is compared across result types.
- [ ] Frequency = Impressions ÷ Reach everywhere; CPM = Cost ÷ Impressions × 1,000 everywhere.
- [ ] Reach and impressions are not mixed up; no unique-reach totals built by summing campaign or breakdown rows.
- [ ] Campaign List has the nine columns in the required order, every delivering campaign, a Total row, and `N/A` where a value is missing.
- [ ] Age, gender, device, and placement tables and charts are labelled correctly; device and placement are not merged.
- [ ] Unknown or unspecified categories are shown; missing metrics read `N/A`.
- [ ] Seven core sections in order (plus campaign continuation slides only if needed); Section 7 covers overall, campaigns, age, gender, and device/placement.
- [ ] No recommendations, next-month plans, optimization advice, or calls to action anywhere (search the text).
- [ ] No ad account ID, token, or other identifier appears in the report.
- [ ] Every slide or section was rendered and checked for overlap, clipping, alignment, label legibility, and consistent formatting.
