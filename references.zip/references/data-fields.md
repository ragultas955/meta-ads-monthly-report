# Data Fields: Mapping Meta Ads Data to Report Metrics

Column names vary by Ads Manager export settings, language, and currency. Match by meaning, not by exact text. If two columns could fit, pick the one that matches the basis stated in the report footnote and say which you used.

## Metric mapping

| Report metric | Typical export column names |
|---|---|
| Campaign name | Campaign name, Campaign |
| Reach | Reach |
| Impressions | Impressions |
| Results | Results |
| Result type | Result indicator, Result type, Objective, Optimization goal |
| CPR | Cost per result |
| CPC | CPC (cost per link click), CPC (all) |
| Clicks | Link clicks, Clicks (all) |
| CPM | CPM (cost per 1,000 impressions) |
| Frequency | Frequency |
| Cost | Amount spent (with a currency code), Spend |

## Breakdown mapping

| Report view | Typical breakdown column |
|---|---|
| Age | Age |
| Gender | Gender |
| Device | Device platform, Impression device |
| Placement | Placement, Platform + Placement |
| Campaign list | Campaign name (no other breakdown) |
| Account totals | No breakdown, or the export's total row |

## Needed exports

For a full report, the data should cover six views for the same period and attribution setting:

1. Account totals (no breakdown)
2. Campaign level (one row per campaign)
3. By age
4. By gender
5. By device
6. By placement

An export with only some of these is fine: build what the data supports and mark the other views `N/A`.

## Connected account queries

When using a Meta Ads connector or API instead of a file:

1. Request each of the six views for the same date range, with the same attribution setting.
2. Request, per campaign: name, objective or result type, reach, impressions, results, cost per result, link clicks or all clicks, CPC, CPM, frequency, spend.
3. If a field comes back empty, mark it `N/A`; do not compute it from other fields unless the formula is listed in the spec and all inputs are present.
4. Keep the ad account ID out of the report.

## Cleaning checklist

- Strip currency symbols and thousands separators before computing; restore consistent formatting after.
- Treat empty cells as missing (`N/A`), not zero.
- Drop export "Total" or "Results from N campaigns" rows from the row data, but keep them as the account-level reference.
- Keep "Unknown" age and gender rows.
- Confirm all rows use one currency. If not, stop and ask.
