# Data Integrity and Insight-Writing Rules

## Why these rules exist

The report goes to a client or to management. A single invented figure or an unsupported explanation damages trust more than a missing metric does. So: show what the data says, label what is calculated, and leave the rest as `N/A`.

## Data integrity

- The provided Meta Ads data (export, pasted table, or connected account) is the only source of truth. Do not estimate, round into a different figure, or fabricate.
- Preserve the exact reporting period, currency, and attribution setting. Use the same ones everywhere.
- Missing metric: write `N/A`. Missing breakdown: say so in the report and in the final reply.
- Calculate derived metrics only when the inputs exist (Frequency needs Impressions and Reach; CPR needs Cost and Results; CPM needs Cost and Impressions; CPC needs Cost and Clicks). Mark calculated values.
- **Reach is not additive** across breakdowns or campaigns. A person can appear in several age groups, devices, placements, or campaigns across a period, so summed reach will not equal unique account reach. Use the account-level reach for totals; show segment and campaign reach as per-row values only. Do not claim shares of "total reach" computed by summing rows. Shares of impressions or cost are fine because those are additive.
- **CPR is only comparable within one result type.** If campaigns use different objectives (for example messages, leads, link clicks), state the result type for each CPR and do not rank or compare across them. At account level, if result types are mixed, show CPR per result type or label any blended CPR as a blended operational figure. In the Campaign List Total row, show `N/A` for Results and CPR when result types differ.
- **CPC basis must be stated.** Link-click CPC and all-click CPC are different metrics. Use the one in the source and label it. Do not mix them in one column.
- **CPM** is Cost ÷ Impressions × 1,000. It measures the price of delivery, not performance, so do not use it to judge efficiency against CPR.
- Keep device and placement as separate dimensions. A "Mobile" row and an "Instagram Reels" row measure different cuts of the same delivery.
- Do not assume rows reconcile exactly to account totals; Meta can suppress small segments or attribute differently. If a table's cost does not sum to total cost, note "segments may not sum to total" rather than adjusting numbers.
- Never put the ad account ID, access tokens, or user identifiers in the report.

## Insight-writing standard

Write like an experienced performance marketing analyst addressing a client, not a generic assistant.

Each insight must:
1. Cite a specific metric or comparison (a number, a share, a ratio).
2. Say what the result indicates in plain business terms.
3. Separate delivery volume (reach, impressions, spend) from cost efficiency (CPR, CPC, CPM).
4. Stay within what the data supports.

Avoid:
- Vague praise: "good performance", "strong engagement", "great results".
- Claims about sales, revenue, leads, or conversions unless the result type is that and the data shows it.
- Calling high frequency good or bad. Describe it: "Frequency of 3.2 means the average reached account saw ads about three times."
- Explaining *why* performance changed (creative fatigue, seasonality, competitor activity) without evidence in the data.
- Naming a "best" campaign, placement, or age group on reach or impressions alone. Use "highest reach" or "lowest CPR" and name the metric.
- Restating chart or table values without saying what they mean.
- Any forward-looking language: recommend, should, consider, opportunity, next month, scale, increase budget, test, optimize.

### Examples

Weak: "25-34 performed best with great reach."
Better: "The 25-34 group delivered the highest reach (X) and the largest share of spend (Y%), while its CPR of Z was above the account average of W for the same result type."

Weak: "Instagram Reels is the top placement."
Better: "Instagram Reels accounted for the largest share of impressions (X%), whereas Facebook Feed recorded the lowest CPR (Z) among placements with the same result type."

Weak: "Campaign A is the best campaign."
Better: "Campaign A held X% of total cost and recorded the lowest CPR (Z) among the N campaigns optimized for the same result type; Campaign B had the highest frequency at F."

Weak: "Frequency is high, which may hurt performance."
Better: "Frequency was 4.1 overall, with the 55-64 group at 5.6, the highest among age groups."

(X, Y, Z, W, F, N are placeholders in these examples only. Real reports use real figures from the source.)

## Length

2-4 insights per analytical section (3-4 for the Overall and Device/Placement sections, 2-3 for the Campaign List), one or two lines each. If an insight takes a paragraph, it is too long for a slide.
