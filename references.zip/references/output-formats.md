# Output Formats and Platform Notes

The user chooses one format. Content, order, and rules are identical in both; only the build method changes.

## Option A: PowerPoint (.pptx)

- 16:9, seven core slides in the order given in `report-spec.md`, plus campaign continuation slides only when there are more than 10 campaigns.
- Native, editable charts and tables (not images of them). Table text 10 pt or larger, body text 11-12 pt or larger.
- Footnotes for calculated metrics and the click basis sit at the bottom of the slide where they apply.
- Build with whatever PowerPoint tooling the environment provides:
  - **Claude**: use the `pptx` skill if available.
  - **ChatGPT**: use python-pptx (or PptxGenJS) in the code environment.
  - **Any other environment**: any library that creates native `.pptx` charts and tables.
- Render the slides to images (for example by converting to PDF, then to PNG) and inspect every one before delivery. Fix overlap, clipping, and illegible labels, and re-render.
- Deliver the `.pptx` file.

## Option B: HTML report (artifact)

A single self-contained `.html` file that shows the same seven sections as a scrolling, slide-like page.

- **Structure**: one `<section>` per report section, in order. The Campaign List is one table with a sticky header row and no row limit.
- **Data**: put all report data in one JavaScript object near the top of the file (`const REPORT = { period, brand, currency, totals, campaigns, age, gender, device, placement }`) and render tables, charts, and KPIs from it. This keeps numbers in one place and makes monthly reuse easy.
- **Charts**: inline SVG or CSS bars, or a charting library loaded as a script from a CDN with a pinned version. No remote images and no network requests for data.
- **Layout**: responsive; wide tables scroll horizontally inside their own container so the page never scrolls sideways. Neutral light background and dark text by default, with a matching dark-mode set of colour variables.
- **Print**: include `@media print` rules (one section per page, landscape) so the user can save a PDF from the browser.
- **No browser storage** and no form tags are needed; the page is read-only.
- **Deliver**:
  - **Claude**: publish the file as an artifact so the user can open and share it.
  - **ChatGPT**: provide the `.html` file as a download (or show it in the canvas if available).
  - **Any other environment**: save a single `.html` file the user can open locally.
- Check the page at desktop and phone widths for clipping and overflow before delivery.

## Platform notes

### Claude
- Can use the `pptx` skill for PowerPoint output and the Artifact tool for the HTML report.
- Can read a connected Meta Ads account through a connector, if the user has one enabled. Use it only to fetch the six views.

### ChatGPT
- The user asks for the monthly Meta Ads report and attaches the export.
- If these reference files are not loaded automatically, the "Core rules" and "Output structure" sections of `SKILL.md` are enough to produce a correct report. Ask the user to upload the reference files for the full spec when the report needs them.
- Use the code environment (python-pptx) for `.pptx`; offer the `.html` file as the artifact-style option.
- If the user has a Meta Ads app or connector enabled, use it as the data source; otherwise ask for an export.

### Both
- Never print the ad account ID, tokens, or any account identifier in the report or in chat.
- If the data is missing, stop and ask. Do not build a sample report.
